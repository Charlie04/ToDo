﻿using Microsoft.AspNetCore.Mvc;
using Todo3.Model;


namespace Todo3.Controllers
{
    [ApiController]
    [Route("[controller]")]
    public class EmployeeController : ControllerBase
    {
        private ApplicationDbContext _context;
        public EmployeeController(ApplicationDbContext context)
        {
            _context = context;
        }

        public static List<Employee> employees = new List<Employee>();

        [HttpGet]
        public IActionResult GetEmployee()
        {
            var employees = _context.Employees.ToList();
            return Ok(employees);
        }     


        [HttpGet("{id}", Name = "Employee")]
        public IActionResult GetEmployeebyID(int id)
        {
           var employee =_context.Employees.Where(t => t.Id == id).FirstOrDefault();
            return Ok(employees);
        }



        [HttpPost]
        public IActionResult CreateEmployee(Employee req)
        {
            if (employees.Any(t => t.Id == req.Id))
            {
                return BadRequest("Employee with this ID already exists. Use a different ID.");
            }
            else
            {
                _context.Employees.Add(req);
                _context.SaveChanges();
                return Ok("new Employee");
            }
        }



        [HttpDelete("{id}", Name = "Delete Employee")]
        public IActionResult DeleteEmployee(int id)
        {
            var employee = _context.Employees.Where(t => t.Id == id).FirstOrDefault();
            _context.Employees.Remove(employee);
            _context.SaveChanges();
            return Ok(employees);
        }



        [HttpPut("{id}")]
        public IActionResult UpdateEmployee(int id, Employee req)
        {
            Employee employee= _context.Employees.Where(t => t.Id == id).FirstOrDefault();
            employee.FirstName = req.FirstName;
            employee.LastName = req.LastName;
            employee.Email = req.Email;
            _context.Employees.Update(employee);
            _context.SaveChanges();
            return Ok(employee);
        }
    }
}


