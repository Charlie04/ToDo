﻿using Microsoft.AspNetCore.Mvc;
using System.Collections.Immutable;
using System.Linq;
using Todo3.Model;

namespace Todo3.Controllers
{
    [ApiController]
    [Route("[controller]")]
    public class TodoController : ControllerBase
    {
        private ApplicationDbContext _context;
        public TodoController(ApplicationDbContext context)
        {
            _context = context;
        }
        public static List<ToDoItem> todos = new List<ToDoItem>();

        [HttpGet]
        public IActionResult GetToDo()
        {
            var todos = _context.ToDoItems.ToList();
            return Ok(todos);
        }


        [HttpGet("{id}",  Name = "ToDo")]
        public IActionResult GetToDobyID(int id)
        {
            ToDoItem todo = _context.ToDoItems.Where(t => t.Id == id).FirstOrDefault();
            return Ok(todos);
        }



        [HttpPost]
        public IActionResult CreateToDo(ToDoItem req) 
        {
            if (todos.Any(t => t.Id == req.Id))
            {
                return BadRequest("Todo with this ID already exists. Use a different ID.");
            }
            else
            {
                _context.ToDoItems.Add(req);
                _context.SaveChanges();
                return Ok("new ToDo");
            }
        }



        [HttpDelete ("{id}" , Name = "Delete ToDo")]
        public IActionResult DeleteToDo(int id )
        {
            ToDoItem todo = _context.ToDoItems.Where(t => t.Id == id).FirstOrDefault();
            _context.ToDoItems.Remove(todo);
            _context.SaveChanges();
            return Ok(todos);
        }



        [HttpPut]
        public IActionResult UpdateToDo(int id, ToDoItem req)
        {
            ToDoItem todo = _context.ToDoItems.Where(t => t.Id == id).FirstOrDefault();
            todo.Title = req.Title;
            todo.IsCompleted = req.IsCompleted;
            _context.ToDoItems.Update(todo);
            _context.SaveChanges();
            return Ok(todos);
        }
    
 }
}
